import React, { useState } from 'react';
import { ArrowLeft, CreditCard, Smartphone, Building2, Check, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import FormulairePaiement from './FormulairePaiement';
import ConfirmationPaiement from './ConfirmationPaiement';

export default function Paiement() {
  const navigate = useNavigate();
  const [etape, setEtape] = useState('plan'); // plan, formulaire, confirmation
  const [planSelectionne, setPlanSelectionne] = useState(null);
  const [paiementConfirme, setPaiementConfirme] = useState(false);

  const plans = [
    {
      id: 'basic',
      nom: 'Plan Basique',
      prix: '9.99',
      duree: 'par mois',
      description: 'Idéal pour débuter',
      couleur: 'blue',
      caracteristiques: [
        'Jusqu\'à 10 produits',
        'Support par email',
        'Statistiques basiques',
        'Durée: 30 jours'
      ]
    },
    {
      id: 'pro',
      nom: 'Plan Pro',
      prix: '29.99',
      duree: 'par mois',
      description: 'Pour les vendeurs actifs',
      couleur: 'purple',
      caracteristiques: [
        'Jusqu\'à 100 produits',
        'Support prioritaire',
        'Analytics avancées',
        'Promotions incluses',
        'Durée: 30 jours'
      ],
      populaire: true
    },
    {
      id: 'enterprise',
      nom: 'Plan Enterprise',
      prix: '99.99',
      duree: 'par mois',
      description: 'Pour les grandes boutiques',
      couleur: 'emerald',
      caracteristiques: [
        'Produits illimités',
        'Support 24/7',
        'Analytics personnalisées',
        'API accès complet',
        'Gestionnaire dédié',
        'Durée: 30 jours'
      ]
    }
  ];

  const handlePlanSelection = (plan) => {
    setPlanSelectionne(plan);
    setEtape('formulaire');
  };

  const handlePaiementSuccess = (donnees) => {
    setPaiementConfirme(true);
    setEtape('confirmation');
  };

  const handleRetourAccueil = () => {
    navigate('/');
  };

  const handleRetourPlans = () => {
    setPlanSelectionne(null);
    setEtape('plan');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50">
      
      {/* Header avec bouton retour */}
      <div className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <button
            onClick={handleRetourAccueil}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors font-medium"
          >
            <ArrowLeft className="w-5 h-5" />
            Retour
          </button>
          <h1 className="text-2xl font-bold text-gray-900">WapiBei Paiement</h1>
          <div className="w-20" /> {/* Spacer pour centrer le titre */}
        </div>
      </div>

      {/* ÉTAPE 1: Sélection du plan */}
      {etape === 'plan' && (
        <div className="py-16 px-4">
          <div className="max-w-6xl mx-auto">
            {/* Titre section */}
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold text-gray-900 mb-4">
                Choisissez votre plan
              </h2>
              <p className="text-lg text-gray-600">
                Lancez votre boutique et vendez vos produits facilement
              </p>
            </div>

            {/* Plans Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {plans.map((plan) => (
                <div
                  key={plan.id}
                  className={`relative rounded-3xl overflow-hidden transition-all duration-300 ${
                    plan.populaire ? 'md:scale-105 md:shadow-2xl' : 'hover:shadow-lg'
                  } ${
                    plan.couleur === 'blue' ? 'bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-200' :
                    plan.couleur === 'purple' ? 'bg-gradient-to-br from-purple-50 to-purple-100 border-2 border-purple-300' :
                    'bg-gradient-to-br from-emerald-50 to-emerald-100 border-2 border-emerald-300'
                  }`}
                >
                  {/* Badge Populaire */}
                  {plan.populaire && (
                    <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                      <span className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-4 py-1 rounded-full text-sm font-bold shadow-lg">
                        POPULAIRE
                      </span>
                    </div>
                  )}

                  <div className="p-8">
                    {/* Titre et description */}
                    <h3 className="text-2xl font-bold text-gray-900 mb-2">{plan.nom}</h3>
                    <p className="text-gray-600 mb-6">{plan.description}</p>

                    {/* Prix */}
                    <div className="mb-6">
                      <span className="text-5xl font-bold text-gray-900">${plan.prix}</span>
                      <span className="text-gray-600 ml-2">{plan.duree}</span>
                    </div>

                    {/* Caractéristiques */}
                    <ul className="space-y-3 mb-8">
                      {plan.caracteristiques.map((carac, idx) => (
                        <li key={idx} className="flex items-center gap-3">
                          <Check className={`w-5 h-5 ${
                            plan.couleur === 'blue' ? 'text-blue-600' :
                            plan.couleur === 'purple' ? 'text-purple-600' :
                            'text-emerald-600'
                          }`} />
                          <span className="text-gray-700">{carac}</span>
                        </li>
                      ))}
                    </ul>

                    {/* Bouton */}
                    <button
                      onClick={() => handlePlanSelection(plan)}
                      className={`w-full py-3 rounded-xl font-bold transition-all duration-300 ${
                        plan.couleur === 'blue' ? 'bg-blue-600 hover:bg-blue-700 text-white' :
                        plan.couleur === 'purple' ? 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white' :
                        'bg-emerald-600 hover:bg-emerald-700 text-white'
                      } ${plan.populaire ? 'shadow-lg' : ''}`}
                    >
                      Continuer
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ÉTAPE 2: Formulaire de paiement */}
      {etape === 'formulaire' && planSelectionne && (
        <FormulairePaiement 
          plan={planSelectionne}
          onSuccess={handlePaiementSuccess}
          onRetour={handleRetourPlans}
        />
      )}

      {/* ÉTAPE 3: Confirmation */}
      {etape === 'confirmation' && planSelectionne && (
        <ConfirmationPaiement 
          plan={planSelectionne}
          onRetourAccueil={handleRetourAccueil}
        />
      )}
    </div>
  );
}
