import React, { useState } from 'react';
import { ArrowLeft, CreditCard, Smartphone, Building2, AlertCircle, Check } from 'lucide-react';

export default function FormulairePaiement({ plan, onSuccess, onRetour }) {
  const [methode, setMethode] = useState('carte');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  
  const [formData, setFormData] = useState({
    // Infos personnelles
    nom: '',
    prenom: '',
    email: '',
    telephone: '',
    
    // Adresse
    rue: '',
    codePostal: '',
    ville: '',
    pays: '',
    
    // Carte bancaire
    numeroCarte: '',
    nomTitulaire: '',
    dateExpiration: '',
    cvv: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleFormatCarte = (e) => {
    let value = e.target.value.replace(/\s/g, '');
    value = value.replace(/(\d{4})/g, '$1 ').trim();
    setFormData(prev => ({
      ...prev,
      numeroCarte: value
    }));
  };

  const handleFormatDateExpiration = (e) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length >= 2) {
      value = value.substring(0, 2) + '/' + value.substring(2, 4);
    }
    setFormData(prev => ({
      ...prev,
      dateExpiration: value
    }));
  };

  const validateForm = () => {
    if (!formData.nom || !formData.prenom || !formData.email) {
      setError('Veuillez remplir tous les champs obligatoires');
      return false;
    }

    if (methode === 'carte') {
      if (!formData.numeroCarte || !formData.cvv || !formData.dateExpiration) {
        setError('Veuillez remplir tous les détails de la carte');
        return false;
      }
      if (formData.numeroCarte.replace(/\s/g, '').length !== 16) {
        setError('Le numéro de carte doit contenir 16 chiffres');
        return false;
      }
      if (formData.cvv.length !== 3) {
        setError('Le CVV doit contenir 3 chiffres');
        return false;
      }
    }

    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (!validateForm()) {
      return;
    }

    setIsLoading(true);

    try {
      // Simuler un délai de traitement
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Appel API pour traiter le paiement
      const response = await fetch('/api/paiement/traiter', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          plan: plan.id,
          methode: methode,
          montant: parseFloat(plan.prix),
          devise: 'USD',
          client: {
            nom: formData.nom,
            prenom: formData.prenom,
            email: formData.email,
            telephone: formData.telephone
          },
          adresse: {
            rue: formData.rue,
            codePostal: formData.codePostal,
            ville: formData.ville,
            pays: formData.pays
          }
        })
      });

      if (!response.ok) {
        throw new Error('Erreur lors du traitement du paiement');
      }

      const data = await response.json();
      onSuccess(data);
    } catch (err) {
      setError(err.message || 'Erreur lors du paiement. Veuillez réessayer.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="py-12 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Bouton retour */}
        <button
          onClick={onRetour}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-8 font-medium"
        >
          <ArrowLeft className="w-5 h-5" />
          Retour aux plans
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Formulaire */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Informations de facturation</h2>

              {error && (
                <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex gap-3">
                  <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                  <p className="text-red-700 text-sm">{error}</p>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Infos personnelles */}
                <div>
                  <h3 className="font-semibold text-gray-900 mb-4">Infos personnelles</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <input
                      type="text"
                      name="prenom"
                      placeholder="Prénom"
                      value={formData.prenom}
                      onChange={handleChange}
                      required
                      className="col-span-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    <input
                      type="text"
                      name="nom"
                      placeholder="Nom"
                      value={formData.nom}
                      onChange={handleChange}
                      required
                      className="col-span-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    <input
                      type="email"
                      name="email"
                      placeholder="Email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="col-span-2 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    <input
                      type="tel"
                      name="telephone"
                      placeholder="Téléphone"
                      value={formData.telephone}
                      onChange={handleChange}
                      className="col-span-2 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                {/* Adresse */}
                <div>
                  <h3 className="font-semibold text-gray-900 mb-4">Adresse</h3>
                  <div className="space-y-4">
                    <input
                      type="text"
                      name="rue"
                      placeholder="Adresse (rue, numéro)"
                      value={formData.rue}
                      onChange={handleChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    <div className="grid grid-cols-2 gap-4">
                      <input
                        type="text"
                        name="codePostal"
                        placeholder="Code postal"
                        value={formData.codePostal}
                        onChange={handleChange}
                        className="px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                      <input
                        type="text"
                        name="ville"
                        placeholder="Ville"
                        value={formData.ville}
                        onChange={handleChange}
                        className="px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <input
                      type="text"
                      name="pays"
                      placeholder="Pays"
                      value={formData.pays}
                      onChange={handleChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                {/* Méthode de paiement */}
                <div>
                  <h3 className="font-semibold text-gray-900 mb-4">Méthode de paiement</h3>
                  <div className="space-y-3">
                    <label className="flex items-center p-4 border-2 rounded-lg cursor-pointer transition-all"
                      style={{borderColor: methode === 'carte' ? '#3b82f6' : '#d1d5db', backgroundColor: methode === 'carte' ? '#eff6ff' : 'white'}}>
                      <input
                        type="radio"
                        name="methode"
                        value="carte"
                        checked={methode === 'carte'}
                        onChange={(e) => setMethode(e.target.value)}
                        className="w-4 h-4"
                      />
                      <CreditCard className="w-5 h-5 ml-3 text-blue-600" />
                      <span className="ml-3 font-medium text-gray-900">Carte bancaire</span>
                    </label>

                    <label className="flex items-center p-4 border-2 rounded-lg cursor-pointer transition-all"
                      style={{borderColor: methode === 'mobile' ? '#3b82f6' : '#d1d5db', backgroundColor: methode === 'mobile' ? '#eff6ff' : 'white'}}>
                      <input
                        type="radio"
                        name="methode"
                        value="mobile"
                        checked={methode === 'mobile'}
                        onChange={(e) => setMethode(e.target.value)}
                        className="w-4 h-4"
                      />
                      <Smartphone className="w-5 h-5 ml-3 text-blue-600" />
                      <span className="ml-3 font-medium text-gray-900">Portefeuille mobile</span>
                    </label>

                    <label className="flex items-center p-4 border-2 rounded-lg cursor-pointer transition-all"
                      style={{borderColor: methode === 'virement' ? '#3b82f6' : '#d1d5db', backgroundColor: methode === 'virement' ? '#eff6ff' : 'white'}}>
                      <input
                        type="radio"
                        name="methode"
                        value="virement"
                        checked={methode === 'virement'}
                        onChange={(e) => setMethode(e.target.value)}
                        className="w-4 h-4"
                      />
                      <Building2 className="w-5 h-5 ml-3 text-blue-600" />
                      <span className="ml-3 font-medium text-gray-900">Virement bancaire</span>
                    </label>
                  </div>
                </div>

                {/* Détails carte (si carte sélectionnée) */}
                {methode === 'carte' && (
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-4">Détails de la carte</h3>
                    <div className="space-y-4">
                      <input
                        type="text"
                        name="numeroCarte"
                        placeholder="Numéro de carte (16 chiffres)"
                        value={formData.numeroCarte}
                        onChange={handleFormatCarte}
                        maxLength="19"
                        required
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono"
                      />
                      <input
                        type="text"
                        name="nomTitulaire"
                        placeholder="Nom du titulaire"
                        value={formData.nomTitulaire}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                      <div className="grid grid-cols-2 gap-4">
                        <input
                          type="text"
                          name="dateExpiration"
                          placeholder="MM/AA"
                          value={formData.dateExpiration}
                          onChange={handleFormatDateExpiration}
                          maxLength="5"
                          required
                          className="px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                        <input
                          type="text"
                          name="cvv"
                          placeholder="CVV"
                          value={formData.cvv}
                          onChange={handleChange}
                          maxLength="3"
                          required
                          className="px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Bouton soumettre */}
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-4 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-lg font-bold text-lg hover:from-blue-700 hover:to-blue-800 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {isLoading ? (
                    <>
                      <svg className="animate-spin w-5 h-5" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"/>
                      </svg>
                      Traitement en cours...
                    </>
                  ) : (
                    <>
                      <Check className="w-5 h-5" />
                      Payer ${plan.prix}
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>

          {/* Résumé du plan */}
          <div className="lg:col-span-1">
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-2xl p-6 border-2 border-blue-200 sticky top-24">
              <h3 className="font-bold text-lg text-gray-900 mb-4">Résumé</h3>
              
              <div className="space-y-3 mb-6 pb-6 border-b border-blue-200">
                <div className="flex justify-between">
                  <span className="text-gray-700">{plan.nom}</span>
                </div>
                <div className="flex justify-between items-end">
                  <span className="text-gray-700">Prix mensuel</span>
                  <span className="text-3xl font-bold text-blue-600">${plan.prix}</span>
                </div>
              </div>

              <div className="space-y-2 mb-6 pb-6 border-b border-blue-200">
                <h4 className="font-semibold text-gray-900 mb-3">Inclus:</h4>
                <ul className="space-y-2">
                  {plan.caracteristiques.map((carac, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-sm text-gray-700">
                      <Check className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
                      {carac}
                    </li>
                  ))}
                </ul>
              </div>

              <p className="text-xs text-gray-600 text-center">
                Vous serez débité de ${plan.prix} maintenant, puis chaque mois à la même date.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
