import React from 'react';
import { CheckCircle, ArrowRight, Download, Share2 } from 'lucide-react';

export default function ConfirmationPaiement({ plan, onRetourAccueil }) {
  const dateFacturation = new Date().toLocaleDateString('fr-FR', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  const dateRenouvellement = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString('fr-FR', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  return (
    <div className="py-16 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Animation success */}
        <div className="flex justify-center mb-8">
          <div className="relative w-24 h-24">
            <div className="absolute inset-0 animate-ping bg-green-400 rounded-full opacity-25"></div>
            <div className="relative flex items-center justify-center w-24 h-24 bg-gradient-to-br from-green-400 to-emerald-500 rounded-full shadow-lg">
              <CheckCircle className="w-12 h-12 text-white" />
            </div>
          </div>
        </div>

        {/* Message de succès */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Paiement confirmé !
          </h1>
          <p className="text-xl text-gray-600 mb-2">
            Merci pour votre achat
          </p>
          <p className="text-gray-500">
            Vous avez souscrit au plan <span className="font-semibold text-gray-900">{plan.nom}</span>
          </p>
        </div>

        {/* Détails de la facturation */}
        <div className="bg-white rounded-2xl p-8 shadow-lg mb-8 border-l-4 border-green-500">
          <h2 className="text-lg font-bold text-gray-900 mb-6">Détails de votre facturation</h2>
          
          <div className="space-y-4 mb-6">
            <div className="flex justify-between items-center pb-4 border-b border-gray-200">
              <span className="text-gray-600">Montant</span>
              <span className="text-2xl font-bold text-gray-900">${plan.prix}</span>
            </div>
            
            <div className="flex justify-between items-center pb-4 border-b border-gray-200">
              <span className="text-gray-600">Durée</span>
              <span className="text-gray-900 font-medium">30 jours</span>
            </div>

            <div className="flex justify-between items-center pb-4 border-b border-gray-200">
              <span className="text-gray-600">Date de facturation</span>
              <span className="text-gray-900 font-medium">{dateFacturation}</span>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-gray-600">Prochain renouvellement</span>
              <span className="text-gray-900 font-medium">{dateRenouvellement}</span>
            </div>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-sm text-blue-800">
              <span className="font-semibold">Numéro de commande:</span> #WB-2024-{Math.random().toString(36).substring(7).toUpperCase()}
            </p>
          </div>
        </div>

        {/* Prochaines étapes */}
        <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-8 mb-8 border-2 border-purple-200">
          <h2 className="text-lg font-bold text-gray-900 mb-6">Prochaines étapes</h2>
          
          <div className="space-y-4">
            <div className="flex items-start gap-4">
              <div className="flex items-center justify-center w-8 h-8 bg-purple-600 text-white rounded-full font-bold flex-shrink-0">
                1
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">Accédez à votre tableau de bord</h3>
                <p className="text-gray-600 text-sm mt-1">Vous pouvez maintenant publier jusqu'à {plan.id === 'basic' ? '10' : plan.id === 'pro' ? '100' : 'illimités'} produits</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="flex items-center justify-center w-8 h-8 bg-purple-600 text-white rounded-full font-bold flex-shrink-0">
                2
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">Complétez votre profil vendeur</h3>
                <p className="text-gray-600 text-sm mt-1">Ajoutez une photo de profil et une description pour attirer plus d'acheteurs</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="flex items-center justify-center w-8 h-8 bg-purple-600 text-white rounded-full font-bold flex-shrink-0">
                3
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">Publiez vos premiers produits</h3>
                <p className="text-gray-600 text-sm mt-1">Commencez à vendre et développez votre boutique WapiBei</p>
              </div>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
          <button
            onClick={onRetourAccueil}
            className="flex items-center justify-center gap-2 px-6 py-4 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-lg font-bold hover:from-blue-700 hover:to-blue-800 transition-all shadow-lg"
          >
            <ArrowRight className="w-5 h-5" />
            Aller au tableau de bord
          </button>

          <button
            className="flex items-center justify-center gap-2 px-6 py-4 bg-white border-2 border-gray-300 text-gray-900 rounded-lg font-bold hover:bg-gray-50 transition-all"
          >
            <Download className="w-5 h-5" />
            Télécharger la facture
          </button>
        </div>

        {/* Besoin d'aide */}
        <div className="bg-gray-50 rounded-lg p-6 text-center">
          <h3 className="font-semibold text-gray-900 mb-2">Besoin d'aide ?</h3>
          <p className="text-gray-600 mb-4">
            Si vous avez des questions, notre équipe support est là pour vous aider
          </p>
          <button className="text-blue-600 hover:text-blue-700 font-semibold">
            Contacter le support
          </button>
        </div>
      </div>
    </div>
  );
}
